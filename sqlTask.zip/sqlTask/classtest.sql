create database test;
use test;

create table Worker(workerId int not null identity(001,1), 
fName varchar(max), lName varchar(max), salary int , joiningDate varchar(max),
dep varchar(max) );

drop table Worker;

create table bonus(worker_Ref_id int not null , bonusDate varchar(max),
bonusAmount int   );

create table title(
worker_Ref_Id int not null
,workerTitle varchar(20), affectedFrom varchar(max)
);

select * from Worker;
insert into Worker values('Monika', 'Arora', 100000, '2014-02-20 09:00:00' , 'HR');

insert into Worker values('Niharika', 'Verma',80000 , '2014-06-11 90:00:00', 'Admin');

insert into Worker values('Vishal', 'Singhal', 300000, '2014-02-20 90:00:00', 'HR');

insert into Worker values('Amitabh', 'Singh', 500000, '2014-02-20 90:00:00', 'Admin');

insert into Worker values('Vivek', 'Bhati', 500000, '2014-06-11 90:00:00', 'Admin');

insert into Worker values('Vipul', 'Diwan', 200000, '2014-06-11 90:00:00' , 'Account');

insert into Worker values('Satish', 'Kumar', 75000, '2014-01-20 90:00:00', 'Account');

insert into Worker values('Geetika', 'Chauhan', 90000, '2014-04-11 90:00:00', 'Admin');

select * from bonus;
insert into bonus values(1,'2016-02-20 00:00:00',5000);

insert into bonus values(2,'2016-06-11 00:00:00',3000);

insert into bonus values(3,'2016-02-20 00:00:00',4000);

insert into bonus values(1,'2016-02-20 00:00:00',4500);

insert into bonus values(2,'2016-06-11 00:00:00',3500);

select * from title;
insert into title values(1,'Manager','2016-02-20 00:00:00');

insert into title values(2,'Executive','2016-06-11 00:00:00');

insert into title values(8,'Executive','2016-06-11 00:00:00');

insert into title values(5,'Manager','2016-06-11 00:00:00');

insert into title values(4,'Asst. Manager','2016-06-11 00:00:00');

insert into title values(7,'Executive','2016-06-11 00:00:00');

insert into title values(6,'Lead','2016-06-11 00:00:00');

insert into title values(3,'Lead','2016-06-11 00:00:00');

--Qi.
select * from Worker;


--Q2.
select * from Worker;
select UPPER(fname) from Worker

--Q3.
select * from Worker;
select distinct(dep) from Worker

--Q4.


